rga.environment <- new.env()

assign("kMaxPages", 100, envir = rga.environment)

assign("kMaxDefaultRows", 10000, envir = rga.environment)