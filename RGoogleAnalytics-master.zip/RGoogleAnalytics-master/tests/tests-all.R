library(testthat)
test_check("RGoogleAnalytics")